#ifndef INTERFACE_H
#define INTERFACE_H

#include <iostream>


/**
 * Receive inputs from user and according to the command, calls the suitable functions from the suitable module
 */
void StartControl();

#endif
