#include <cstdlib>
#include <iostream>
#include "Interface.h"

int main(int argc, char *argv[])
{
    StartControl();
        
    system("PAUSE");
    return EXIT_SUCCESS;
}
